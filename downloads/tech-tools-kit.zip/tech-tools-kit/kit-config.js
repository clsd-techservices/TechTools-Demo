/*
 * Tech Tools Kit - district configuration
 * -------------------------------------------------------------
 * Don't edit by hand unless you want to: open setup.html, fill in
 * your district's details, and download a new copy of this file.
 * Every tool in the kit reads these values on load.
 *
 * Copyright (c) 2026 Scott Boyer, Systems Coordinator, CLSD Technology Services. MIT License (see LICENSE).
 */
window.KIT_CONFIG = {
  configured: false,
  version: 1,

  identity: {
    districtName:  "Your School District",
    districtShort: "YSD",
    deptName:      "Technology Services",
    portalName:    "Tech Tools",
    authorName:    "IT Department",
    authorTitle:   "",
    supportEmail:  "",
    logFolder:     "YSD"          // used in script log paths, e.g. %LOCALAPPDATA%\YSD\IntuneLogs
  },

  brand: {
    primary:   "#2563eb",
    secondary: "#60a5fa",
    bgTint:    "brand",           // brand | navy | neutral
    logo:      "assets/kit-logo.svg",
    watermark: "logo",            // "logo" | "none" | image path or data URI
    watermarkOpacity: 0.06
  },

  microsoft: {
    tenantId:      "",            // leave blank to run the tools in offline/demo mode
    clientId:      "",
    primaryDomain: "",
    groupTagExamples: "Staff-HS, 1to1-MS, Cart-ES"
  },

  ai: {
    provider:         "anthropic", // anthropic | openai | groq | gemini
    model:            "",
    fallbackProvider: "",
    fallbackModel:    "",
    keyStorage:       "browser",   // browser = each user enters a key once, kept only in their browser
    keys: {}                       // only filled when keyStorage = "config" (not recommended for hosted kits)
  }
};
